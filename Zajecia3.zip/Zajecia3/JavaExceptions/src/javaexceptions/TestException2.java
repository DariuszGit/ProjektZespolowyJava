/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaexceptions;

/**
 *
 * @author Student
 */
public class TestException2 extends Exception implements ExceptionInterface{
    private String text;
    
    public TestException2 (String text)
    {
        this.text = text;
    }

    public void printMessage() {
        System.out.println(text);
    }
}
