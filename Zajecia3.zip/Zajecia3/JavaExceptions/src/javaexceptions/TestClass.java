/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaexceptions;

/**
 *
 * @author Student
 */
public class TestClass {
    public void throwException() throws TestException
    {
       throw new TestException("Wyjatek rzucony z klasy");  
    }
    
    public void f() throws TestException
    {
        throw new TestException("Wyjatek rzucony z klasy"); 
    }
    
    public void g() throws TestException2
    {
        try
        {
            f();
        }
        catch (TestException exc)
        {
            throw new TestException2("Wyjatek klasy TestException2");
        }
    }
    
    public void h() throws TestException3
    {
        throw new TestException3("wyjatek3");
    }
    
    public void i(int exceptionNumber) throws TestException, TestException2, TestException3
    {
        if (exceptionNumber == 1)
        {
            throw new TestException("Wyjatek typu 1");
        }
        else if (exceptionNumber == 2)
        {
            throw new TestException2("Wyjatek typu 2");
        }
        else
        {
            throw new TestException3("Wyjatek typu 3");
        }
    }
}
