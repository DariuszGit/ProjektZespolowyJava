/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaexceptions;

import sun.net.www.content.audio.x_aiff;

/**
 *
 * @author Student
 */
public class JavaExceptions {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        try
        {
            throw new Exception("Rzucony wyjatek");
        }
        catch (Exception exc)
        {
            System.out.println(exc.getMessage());
        }
        finally
        {
            System.out.println("Blok finally");
        }
        
        try
        {
            throw new TestException("Rzucony nowy wyjatek");
        }
        catch (TestException exc)
        {
            exc.printMessage();
        }
        finally
        {
            System.out.println("Blok finally");
        }
        
        try
        {
            TestClass cls = new TestClass();
            cls.throwException();
        }
        catch (TestException exc)
        {
            exc.printMessage();
        }
        finally
        {
            System.out.println("Blok finally");
        }
        
        
        TestClass cls = null;
        
        try
        {           
            cls.throwException();
        }
        catch (Exception exc)
        {
            System.out.println(exc.getMessage());
        }
        finally
        {
            System.out.println("Blok finally");
        }
        
        try
        {      
            cls = new TestClass();
            cls.g();
        }
        catch (TestException2 exc)
        {
            exc.printMessage();
        }
        finally
        {
            System.out.println("Blok finally");
        }
        
        //zadanie 6
        try
        {      
            cls = new TestClass();
            cls.h();
        }
        catch (RuntimeException exc)
        {
            System.out.println("Zlapany wyjatek runtime exception.");
        }
        finally
        {
            System.out.println("Blok finally po wyjatku runtime.");
        }
        
        //zadanie 7
        System.out.println("Zadanie 7.");
        
         try
        {      
            cls = new TestClass();
            cls.i(3);
        }
        catch (TestException | TestException2 | TestException3 e)
        {
            e.printMessage();
        }
        finally
        {
            System.out.println("Blok finally po wyjatku runtime.");
        }
        
         //zadanie 8
         System.out.println("Zadanie 8.");
         try
         {
             int[] ints = new int[5];
             int x = ints [7];
         }
         catch (ArrayIndexOutOfBoundsException exc)
         {
             System.out.println("Rzucony wyjatek z powodu przekrowczenia indeku tablicy.");
         }
         
         //zadanie 9
         boolean canLoop = true;
         int i = 15;
         while(canLoop)
         {
            canLoop = false;
            i -= 1;
            
            try
            {
                int[] ints = new int[5];
                int x = ints [i];
            }
            catch (ArrayIndexOutOfBoundsException exc)
            {
                System.out.println("Rzucony wyjatek z powodu przekrowczenia indeku tablicy.");
                canLoop = true;
            }
            
            
            
         }
    }
    
}
