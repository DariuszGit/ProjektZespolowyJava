/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javagenerics;

/**
 *
 * @author Student
 */
public class JavaGenerics {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Test<String, Integer> test = new Test<>();
        test.setField1("Value1");
        test.setField2(2);
        
        String x = test.getField1();
        Integer y = test.getField2();
        
        Stos<String> stos = new Stos<String>();
        stos.Push("Element1");
        stos.Push("Element2");
        stos.Push("Element3");
        System.out.println(stos.pop());
        System.out.println(stos.pop());
        System.out.println(stos.pop());

    }
    
}
