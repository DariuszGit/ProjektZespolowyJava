/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javagenerics;

/**
 *
 * @author Student
 * @param <T>
 * @param <U>
 */
public class Test<T extends String, U extends Integer> {
    private T field1;
    private U field2;
    
    public T getField1()
    {
        return field1;
    }
    
    public U getField2()
    {
        return field2;
    }
    
    public void setField1(T value)
    {
        field1 = value;
    }
    
    public void setField2(U value)
    {
        field2 = value;
    }    
}
