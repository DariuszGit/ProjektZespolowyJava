/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javagenerics;

/**
 *
 * @author Student
 */
public class Algorytm {
    //public static <T extends Comparable<T>> min (Stos <T>)
    //{
        
    //}
}
