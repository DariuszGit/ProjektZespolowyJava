/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javagenerics;

/**
 *
 * @author Student
 */
public class Stos<T extends Comparable> {
    
    Pair first;    
    
    public void Push(T elem)
    {
        if (first != null)
        {
            Pair x = new Pair();
            x.setElem(elem);
            x.setNext(first);
            first = x;
        }
        else
        {
            first = new Pair();
            first.setElem(elem);
            first.setNext(null);
        }
    }
    
    public T pop()
    {
        T value = first.getElem();
        
        first = first.getNext();
        
        return value;
    }
    
    public T GetFirst()
    {
        return first.getElem();
    }
    
    
    private class Pair {
        T elem;
        Pair next;
        
        public T getElem()
        {
            return elem;
        }
        
        public Pair getNext()
        {
            return next;
        }
        
        public void setElem(T value)
        {
            elem = value;
        }
        
        public void setNext(Pair value)
        {
            next = value;
        }
    }
}
